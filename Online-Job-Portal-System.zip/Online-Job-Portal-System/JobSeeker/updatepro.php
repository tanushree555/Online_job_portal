<?php

session_start();

	$JobSeekId=$_SESSION['ID'];
// Establish Connection with Database
$con = mysqli_connect("localhost","root","","job");
// Specify the query to execute
$sql = "select * from JobSeeker_Reg where JobSeekId='$ID'";
// Execute query
$result = mysqli_query($con,$sql);
// Loop through each records 
$row = mysqli_fetch_array($result)
?>

<?php
if(isset($_POST['edit'])) // when click on Update button
{
    $fullname = $_POST['JobSeekerName'];
    $Address = $_POST['Address'];
    $City= $_POST['City'];
    $Email=$_POST['Email'];		
    $Mobile=$_POST['Mobile'];
    $Qualification=$_POST['Qualification'];
    $Gender=$_POST['Gender'];
    $BirthDate=$_POST['BirthDate'];
    
$edit = mysqli_query($db,"update JobSeeker_Reg   set fullname='$JobSeekerName', Address='$Address', City='$City', Email='$Email', Mobile='$Mobile',
Qualification='$Qualification',Gender='$Gender', BirthDate='$BirthDate' where id='$ID'");
	
    if($edit)
    {
        mysqli_close($db); // Close connection
        header("location:Profile.php"); // redirects to all records page
        exit;
    }
    else
    {
        echo mysqli_error();
    }    	
}
?>
<h3>Update Data</h3>

<form method="POST">
  <input type="text" name="Name" value="<?php echo $data['fullname'] ?>" placeholder="Enter Full Name" Required>
  <input type="text" name="Address" value="<?php echo $data['Address'] ?>" placeholder="Address" Required>
  <input type="text" name="City" value="<?php echo $data['City'] ?>" placeholder="City" Required>
  <input type="text" name="Email" value="<?php echo $data['Email'] ?>" placeholder="Email" Required>
  <input type="text" name="Mobile" value="<?php echo $data['Mobile'] ?>" placeholder="Mobile" Required>
  <input type="text" name="Qualification" value="<?php echo $data['Qualification'] ?>" placeholder="Qualification" Required>
  <input type="text" name="Gender" value="<?php echo $data['Gender'] ?>" placeholder="Gender" Required>
  <input type="text" name="BirthDate" value="<?php echo $data['BirthDate'] ?>" placeholder="Birth Date" Required>
  <input type="submit" name="update" value="Update">
</form>
